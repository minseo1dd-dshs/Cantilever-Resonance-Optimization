# GitHub 업로드 방법

## 방법 1 — 웹에서 올리기

1. ZIP 압축을 풉니다.
2. GitHub 로그인 → 우측 위 `+` → **New repository** → 저장소 이름 입력 → **Create repository**.
3. 저장소에서 **uploading an existing file** 또는 **Add file → Upload files**를 선택합니다.
4. 압축 해제한 프로젝트의 **파일과 하위 폴더를 업로드**합니다. ZIP 자체만 올리면 소스 코드가 펼쳐져 보이지 않습니다.
5. 아래쪽 **Commit changes**를 눌러 저장합니다.
6. 주소창에 표시된 `https://github.com/사용자명/저장소명`을 연구보고서의 코드 링크로 넣습니다.

## 방법 2 — Windows PowerShell + Git

먼저 [Git for Windows](https://git-scm.com/downloads/win)를 설치한 뒤, GitHub에서 내용이 없는 저장소를 만들고, 압축을 푼 프로젝트 폴더 안에서 PowerShell을 열어 다음 명령을 실행합니다.

```powershell
git init
git add .
git commit -m "Add cantilever optimization implementation"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

`YOUR_USERNAME`과 `YOUR_REPOSITORY`를 실제 GitHub 사용자명과 저장소명으로 바꿉니다. GitHub 로그인/인증이 필요할 수 있습니다.

## 보고서에 넣을 문장

> 전체 구현 코드는 GitHub 저장소(https://github.com/사용자명/저장소명)에 공개하였다.

**주의:** 첨부 보고서에 나온 설명을 바탕으로 재구현한 코드입니다. 실제 연구에 사용한 원본 코드를 공개하는 것이 목적이라면, 팀이 사용한 원본 `.py` 파일과 이 구현을 비교·확인한 뒤 업로드해야 합니다.
