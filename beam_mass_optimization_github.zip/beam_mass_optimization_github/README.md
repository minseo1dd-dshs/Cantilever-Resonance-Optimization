# Two-Mass Cantilever Resonance Avoidance & Bending-Moment Optimization

두 개의 동일한 집중질량을 외팔보에 부착할 때, 지정한 **1차·2차 고유진동수 회피 범위**를 모두 만족하는 배치 중 **고정단의 추가 굽힘모멘트가 가장 작은 배치**를 찾는 Python 코드입니다.

> **출처/범위:** 첨부된 연구보고서 「두 질량체의 배치 최적화를 통한 외팔보의 공진 회피 및 굽힘모멘트 최소화 알고리즘 개발」의 3~5장에 설명된 수식과 계산 절차를 바탕으로 **새로 작성한 재구현 코드**입니다. 연구에 사용된 원본 Python 소스 전체를 입수한 것은 아니므로, 원본과 파일 구성 및 세부 구현은 다를 수 있습니다. 본 코드의 실행값과 보고서 수치는 대표 사례에서 대조했습니다.

## 1. 구현 내용

1. 오일러–베르누이 보의 2절점 요소 / 3차 에르미트 보간함수 구성
2. 요소 강성행렬과 일관 질량행렬 조립 (고정단 변위·회전각 자유도 제거)
3. 임의의 부착 위치에 집중질량의 추가 질량행렬 `m Nᵀ N` 반영
4. 일반화 고유값 문제 `K φ = ω² M φ`를 풀어 1·2차 고유진동수 예측
5. 순서가 같은 두 질량체의 배치 `(a, b)`를 중복 없이 열거 (같은 위치의 배치 허용)
6. 두 고유진동수가 지정 회피 구간의 **밖**에 놓인 배치만 채택 (경계값은 구간에 포함)
7. `T = m g (2L − a − b)`가 최소인 배치 선정
8. 추가 굽힘모멘트가 같은 배치끼리는 회피 여유 `D = min(d₁, d₂)`가 최대인 배치를 선택

**단위:** 입력 설정은 길이 m, 질량 kg, 굽힘강성 N·m², 주파수 Hz를 사용합니다. 부착 위치 `a`, `b`만 **자유단에서 고정단 방향으로 잰 cm**로 받습니다. 질량체 둘은 서로 구분하지 않습니다.

## 2. 실행

Python 3.10 이상 권장. GitHub에서 받은 폴더를 열고 터미널(Windows에서는 PowerShell)에서:

```powershell
python -m pip install -r requirements.txt
python main.py --preset 15cm
```

세 가지 보고서 사례를 그대로 실행할 수 있습니다.

```powershell
# 5장: 15 cm, 50 g x 2 / 후보 78개
python main.py --preset 15cm --csv results/15cm_candidates.csv

# 4장: 30 cm, 99 g x 2 / 3 cm 간격, 동률 때 회피 여유 비교
python main.py --preset 30cm-tie --csv results/30cm_tie_candidates.csv

# 5장: 30 cm, 99 g x 2 / 1 cm 간격, 후보 325개
python main.py --preset 30cm-1cm --csv results/30cm_1cm_candidates.csv
```

`--csv`를 생략하면 화면에 요약 결과만 표시됩니다. 생성한 CSV에는 전체 배치별 예측값, 회피 조건 통과 여부, 추가 굽힘모멘트, 회피 여유가 저장됩니다.

## 3. 논문/보고서 대표 사례와 대조

| 조건 | 후보 배치 | 허용 배치 | 최적 배치 (자유단에서 cm) | 최소 추가 굽힘모멘트 |
|---|---:|---:|---|---:|
| 4장 30 cm·99 g, 3 cm 간격, 10.5–14 / 58–87 Hz | 45 | 18 | (21, 12) | 약 0.2622 N·m |
| 5장 15 cm·50 g, 1 cm 간격, 44–60 / 216–330 Hz | 78 | 30 | (7, 12) | 약 0.05396 N·m |
| 5장 30 cm·99 g, 1 cm 간격, 11.5–14 / 77–87 Hz | 325 | 257 | (16, 27) | 약 0.1651 N·m |

- 두 질량체의 질량은 같기 때문에 `(21, 12)`와 `(12, 21)`은 동일한 배치입니다. 프로그램은 중복 제거를 위해 숫자가 작은 위치를 먼저 출력합니다.
- 15 cm 사례에서 허용 배치 30개의 평균 굽힘모멘트는 약 0.07848 N·m, 최댓값은 약 0.10791 N·m이며, 최적 배치의 감소율은 각각 약 31.25%, 50.00%입니다.
- 기하학적 제약, 주파수 회피 범위, 장치의 질량·강성에 따라 최적 배치와 허용 배치 수는 변합니다.

## 4. 실측 비교 (보고서 표 5-5)

15 cm·50 g 실험의 A~E 실측값은 `data/validation_15cm_50g.csv`에 입력해 두었습니다. 아래 명령은 예측값을 다시 계산하고 실측값과 비교합니다.

```powershell
python validate_report.py
```

결과: 1차/2차 MAPE 약 1.41% / 0.72%, 5개 배치에서 예측 회피 판정과 실측 회피 판정이 일치합니다. 이 다섯 배치의 결과로 전체 78개 배치에서의 실험적 전역 최적성이 검증되는 것은 아닙니다.

## 5. 설정 변경

`examples/15cm_validation.json` 등의 파일을 복사해 실험 조건을 수정합니다.

```json
{
  "name": "My cantilever",
  "beam": {
    "length_m": 0.15,
    "beam_mass_kg": 0.05124,
    "point_mass_kg": 0.05,
    "bending_rigidity_Nm2": 1.52448,
    "elements": 40,
    "gravity_m_s2": 9.81
  },
  "positions_cm": {"min": 2, "max": 13, "step": 1},
  "avoid_Hz": {"first": [44, 60], "second": [216, 330]}
}
```

실행:

```powershell
python main.py --config examples/my_experiment.json --csv results/my_experiment.csv
```

`positions_cm`의 `max - min`은 `step`으로 나누어떨어지도록 설정합니다. 수치해석 모델은 작은 변형·선형 탄성, 일정한 EI, 집중질량의 보와 같은 횡변위, 질량체 회전관성 및 기하강성 변화 무시를 전제로 합니다.

## 6. 테스트

```powershell
python -m unittest discover -s tests -v
```

테스트는 1·2차 고유진동수, 후보 수, 허용 배치 수, 최적 배치, 동률일 때 회피 여유 적용을 확인합니다.

## 파일 구조

```text
beam_mass_optimization_github/
├── beam_optimizer.py             # FEM 계산과 배치 최적화
├── main.py                       # 실행 및 CSV 저장
├── validate_report.py            # 표 5-5 실측과 예측값 비교
├── requirements.txt
├── examples/
│   ├── 15cm_validation.json
│   ├── 30cm_tie.json
│   └── 30cm_1cm.json
├── data/
│   └── validation_15cm_50g.csv
├── tests/
│   └── test_algorithm.py
└── GITHUB_UPLOAD.md              # GitHub 업로드 방법
```

## 참고

이 코드는 설정한 **고유진동수 범위 회피**를 판정합니다. 실제 가진 실험에서의 진동 진폭이나 감쇠 성능을 직접 예측·검증하는 프로그램은 아닙니다. 실행 시간 역시 보고서와 완전히 같을 필요는 없습니다(컴퓨터, 라이브러리 버전, 계산 루틴의 차이).
