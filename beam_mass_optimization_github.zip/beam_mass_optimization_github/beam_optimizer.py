"""Euler–Bernoulli cantilever: two equal point masses, frequency avoidance and moment minimization.

Report-based reimplementation. It is not claimed to be the research team's original source.
All SI units internally; attachment positions are reported from the free end in centimeters.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations_with_replacement
from typing import Iterable
import math

import numpy as np
from scipy.linalg import eigh


@dataclass(frozen=True)
class BeamParameters:
    length_m: float
    beam_mass_kg: float
    point_mass_kg: float
    bending_rigidity_Nm2: float
    elements: int = 40
    gravity_m_s2: float = 9.81

    def __post_init__(self) -> None:
        if any(v <= 0 for v in (self.length_m, self.beam_mass_kg,
                                  self.point_mass_kg, self.bending_rigidity_Nm2,
                                  self.gravity_m_s2)):
            raise ValueError("Beam parameters must be positive.")
        if self.elements < 1:
            raise ValueError("Number of finite elements must be >= 1.")


@dataclass(frozen=True)
class AvoidanceBands:
    first_Hz: tuple[float, float]
    second_Hz: tuple[float, float]

    def __post_init__(self) -> None:
        for lo, hi in (self.first_Hz, self.second_Hz):
            if not (0 <= lo < hi):
                raise ValueError("Frequency ranges require 0 <= lower < upper.")


@dataclass(frozen=True)
class PlacementResult:
    a_cm: float
    b_cm: float
    f1_Hz: float
    f2_Hz: float
    moment_Nm: float
    pass_first: bool
    pass_second: bool
    margin_Hz: float

    @property
    def feasible(self) -> bool:
        return self.pass_first and self.pass_second

    def to_row(self) -> dict[str, float | bool]:
        return {
            "a_cm": self.a_cm,
            "b_cm": self.b_cm,
            "f1_Hz": self.f1_Hz,
            "f2_Hz": self.f2_Hz,
            "additional_moment_Nm": self.moment_Nm,
            "pass_f1": self.pass_first,
            "pass_f2": self.pass_second,
            "feasible": self.feasible,
            "avoidance_margin_Hz": self.margin_Hz,
        }


class CantileverFEM:
    """Consistent-mass, cubic-Hermite Euler–Bernoulli beam discretization."""

    def __init__(self, parameters: BeamParameters):
        self.p = parameters
        self.element_length = parameters.length_m / parameters.elements
        self.K, self.M0 = self._assemble()

    def _assemble(self) -> tuple[np.ndarray, np.ndarray]:
        n = self.p.elements
        le = self.element_length
        mu = self.p.beam_mass_kg / self.p.length_m
        EI = self.p.bending_rigidity_Nm2

        ke = (EI / le**3) * np.array([
            [12, 6*le, -12, 6*le],
            [6*le, 4*le**2, -6*le, 2*le**2],
            [-12, -6*le, 12, -6*le],
            [6*le, 2*le**2, -6*le, 4*le**2],
        ], dtype=float)
        me = (mu * le / 420) * np.array([
            [156, 22*le, 54, -13*le],
            [22*le, 4*le**2, 13*le, -3*le**2],
            [54, 13*le, 156, -22*le],
            [-13*le, -3*le**2, -22*le, 4*le**2],
        ], dtype=float)

        # Fixed-end degrees of freedom (global indices 0 and 1) removed.
        # Reduced global indices: 0 .. 2*n-1.
        dim = 2 * n
        K = np.zeros((dim, dim), dtype=float)
        M0 = np.zeros((dim, dim), dtype=float)
        for e in range(n):
            global_dofs = (2*e, 2*e + 1, 2*e + 2, 2*e + 3)
            active = [(i, gdof - 2) for i, gdof in enumerate(global_dofs) if gdof >= 2]
            for i, ii in active:
                for j, jj in active:
                    K[ii, jj] += ke[i, j]
                    M0[ii, jj] += me[i, j]
        return K, M0

    def _attach_mass_at_fixed_origin_coordinate(self, M: np.ndarray, x_m: float) -> None:
        """Add m N(s)^T N(s) at x measured from the fixed end."""
        if x_m < -1e-12 or x_m > self.p.length_m + 1e-12:
            raise ValueError("Attachment position must be within the beam.")
        x_m = min(max(x_m, 0.0), self.p.length_m)
        le = self.element_length
        e = min(int(x_m / le), self.p.elements - 1)
        s = (x_m - e * le) / le
        N = np.array([
            1 - 3*s**2 + 2*s**3,
            le*(s - 2*s**2 + s**3),
            3*s**2 - 2*s**3,
            le*(-s**2 + s**3),
        ], dtype=float)
        mp = self.p.point_mass_kg * np.outer(N, N)
        gdofs = (2*e, 2*e + 1, 2*e + 2, 2*e + 3)
        for i, gi in enumerate(gdofs):
            if gi < 2:
                continue
            for j, gj in enumerate(gdofs):
                if gj >= 2:
                    M[gi-2, gj-2] += mp[i, j]

    def frequencies(self, a_cm: float, b_cm: float) -> tuple[float, float]:
        """1st/2nd natural frequency for two equal point masses.

        a_cm, b_cm are measured inward from the free end (as in the report).
        """
        for v in (a_cm, b_cm):
            if not 0 <= v <= self.p.length_m * 100 + 1e-10:
                raise ValueError("a_cm and b_cm must lie on the cantilever.")
        M = self.M0.copy()
        for d_cm in (a_cm, b_cm):
            self._attach_mass_at_fixed_origin_coordinate(M, self.p.length_m - d_cm/100)
        values = eigh(self.K, M, eigvals_only=True, subset_by_index=(0, 1),
                      check_finite=False, driver="gvx")
        if values[0] <= 0:
            raise ArithmeticError("Non-positive squared frequency; inspect inputs.")
        result = np.sqrt(values) / (2 * math.pi)
        return float(result[0]), float(result[1])


def outside_band(frequency: float, band: tuple[float, float]) -> bool:
    """Frequency at the endpoints is considered inside the avoidance band."""
    return frequency < band[0] or frequency > band[1]


def distance_from_band(frequency: float, band: tuple[float, float]) -> float:
    if frequency < band[0]:
        return band[0] - frequency
    if frequency > band[1]:
        return frequency - band[1]
    return 0.0


def additional_moment(p: BeamParameters, a_cm: float, b_cm: float) -> float:
    """T = mg(2L - a - b)."""
    return p.point_mass_kg * p.gravity_m_s2 * (2*p.length_m - (a_cm+b_cm)/100)


def grid_positions(min_cm: float, max_cm: float, step_cm: float) -> list[float]:
    if step_cm <= 0 or min_cm < 0 or max_cm < min_cm:
        raise ValueError("Invalid attachment position range or interval.")
    steps = (max_cm - min_cm) / step_cm
    if not math.isclose(steps, round(steps), abs_tol=1e-8, rel_tol=0.0):
        raise ValueError("(max_cm - min_cm) must be divisible by step_cm.")
    return [round(min_cm + k * step_cm, 9) for k in range(round(steps)+1)]


def evaluate_positions(model: CantileverFEM, bands: AvoidanceBands,
                       positions_cm: Iterable[float]) -> list[PlacementResult]:
    positions = sorted(set(positions_cm))
    for x in positions:
        if not 0 <= x <= model.p.length_m*100:
            raise ValueError("Grid must stay within cantilever length.")
    records = []
    for a, b in combinations_with_replacement(positions, 2):
        f1, f2 = model.frequencies(a, b)
        ok1 = outside_band(f1, bands.first_Hz)
        ok2 = outside_band(f2, bands.second_Hz)
        margin = min(distance_from_band(f1, bands.first_Hz),
                     distance_from_band(f2, bands.second_Hz))
        records.append(PlacementResult(a, b, f1, f2,
                       additional_moment(model.p, a, b), ok1, ok2, margin))
    return records


def choose_optimum(results: Iterable[PlacementResult]) -> PlacementResult | None:
    """Minimize additional moment; break exact physical ties by max avoidance margin.

    The absolute moment tolerance only absorbs floating point round-off from
    summing attachment coordinates; it does not create a substantive tolerance.
    """
    feasible = [r for r in results if r.feasible]
    if not feasible:
        return None
    minimum = min(r.moment_Nm for r in feasible)
    tied = [r for r in feasible if math.isclose(r.moment_Nm, minimum,
                                               abs_tol=1e-11, rel_tol=0.0)]
    return sorted(tied, key=lambda r: (-r.margin_Hz, r.a_cm, r.b_cm))[0]
