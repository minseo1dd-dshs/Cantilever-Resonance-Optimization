"""Command-line interface for the report-based cantilever mass placement optimizer."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP

from beam_optimizer import (BeamParameters, AvoidanceBands, CantileverFEM,
                            grid_positions, evaluate_positions, choose_optimum)


ROOT = Path(__file__).resolve().parent
PRESETS = {
    "30cm-tie": ROOT / "examples" / "30cm_tie.json",
    "15cm": ROOT / "examples" / "15cm_validation.json",
    "30cm-1cm": ROOT / "examples" / "30cm_1cm.json",
}


def run(config_path: Path, csv_path: Path | None = None) -> None:
    with config_path.open(encoding="utf-8") as f:
        config = json.load(f)
    p = BeamParameters(**config["beam"])
    bands = AvoidanceBands(tuple(config["avoid_Hz"]["first"]),
                           tuple(config["avoid_Hz"]["second"]))
    position_cfg = config["positions_cm"]
    positions = grid_positions(position_cfg["min"], position_cfg["max"],
                               position_cfg["step"])
    model = CantileverFEM(p)
    results = evaluate_positions(model, bands, positions)
    best = choose_optimum(results)
    feasible = [r for r in results if r.feasible]

    print(config.get("name", config_path.name))
    print(f"  Elements: {p.elements}")
    print(f"  Candidate placements: {len(results)}")
    print(f"  Feasible placements: {len(feasible)}")
    if best is None:
        print("  No placement satisfies both frequency avoidance constraints.")
    else:
        print(f"  Optimal placement (from free end): a={best.a_cm:g} cm, b={best.b_cm:g} cm")
        print(f"  Frequencies: f1={best.f1_Hz:.3f} Hz, f2={best.f2_Hz:.3f} Hz")
        # Round report display values using decimal half-up, e.g. 0.053955 -> 0.05396.
        exact_moment = (Decimal(str(p.point_mass_kg)) * Decimal(str(p.gravity_m_s2)) *
                        (2 * Decimal(str(p.length_m)) -
                         (Decimal(str(best.a_cm)) + Decimal(str(best.b_cm))) / Decimal(100)))
        displayed_moment = exact_moment.quantize(Decimal("0.00001"), rounding=ROUND_HALF_UP)
        print(f"  Additional bending moment: {displayed_moment} N*m")
        print(f"  Avoidance margin: {best.margin_Hz:.3f} Hz")
        if feasible:
            mean_moment = sum(r.moment_Nm for r in feasible) / len(feasible)
            max_moment = max(r.moment_Nm for r in feasible)
            print(f"  Mean feasible moment: {mean_moment:.5f} N*m")
            print(f"  Reduction vs mean: {(1 - best.moment_Nm/mean_moment)*100:.2f}%")
            print(f"  Reduction vs maximum: {(1 - best.moment_Nm/max_moment)*100:.2f}%")

    if csv_path is not None:
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0].to_row()))
            writer.writeheader()
            writer.writerows(r.to_row() for r in results)
        print(f"  Saved results: {csv_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Two-mass cantilever frequency-avoidance optimizer")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--preset", choices=sorted(PRESETS), default="15cm",
                       help="Built-in experiment configuration (default: 15cm)")
    group.add_argument("--config", type=Path, help="Custom JSON input configuration")
    parser.add_argument("--csv", type=Path, help="Optional CSV output path")
    args = parser.parse_args()
    run(args.config if args.config is not None else PRESETS[args.preset], args.csv)


if __name__ == "__main__":
    main()
