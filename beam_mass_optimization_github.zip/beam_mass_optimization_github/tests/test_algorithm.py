"""Standard-library regression tests against report examples."""
import unittest

from beam_optimizer import (BeamParameters, AvoidanceBands, CantileverFEM,
                            grid_positions, evaluate_positions, choose_optimum,
                            outside_band, distance_from_band)


class AlgorithmTests(unittest.TestCase):
    def test_grid_size_and_collocated_masses(self):
        self.assertEqual(len(grid_positions(3, 27, 3)), 9)
        self.assertEqual(len(grid_positions(2, 13, 1)), 12)
        self.assertEqual(len(grid_positions(3, 27, 1)), 25)
        self.assertFalse(outside_band(44, (44, 60)))
        self.assertEqual(distance_from_band(42.7, (44, 60)), 44-42.7)

    def test_fem_15cm_frequencies_report_B(self):
        model = CantileverFEM(BeamParameters(0.15, 0.05124, 0.050, 1.52448, 40))
        f1, f2 = model.frequencies(7, 12)
        self.assertAlmostEqual(f1, 41.574, delta=0.002)
        self.assertAlmostEqual(f2, 210.764, delta=0.002)
        self.assertAlmostEqual(model.frequencies(12, 7)[0], f1, delta=0.0001)

    def test_15cm_optimal_placement(self):
        model = CantileverFEM(BeamParameters(0.15, 0.05124, 0.050, 1.52448, 40))
        bands = AvoidanceBands((44, 60), (216, 330))
        records = evaluate_positions(model, bands, grid_positions(2, 13, 1))
        best = choose_optimum(records)
        self.assertEqual(len(records), 78)
        self.assertEqual(sum(r.feasible for r in records), 30)
        self.assertEqual((best.a_cm, best.b_cm), (7, 12))
        self.assertAlmostEqual(best.moment_Nm, 0.053955, delta=0.000001)

    def test_30cm_tie_margin(self):
        model = CantileverFEM(BeamParameters(0.30, 0.10248, 0.099, 1.52448, 40))
        bands = AvoidanceBands((10.5, 14), (58, 87))
        records = evaluate_positions(model, bands, grid_positions(3, 27, 3))
        best = choose_optimum(records)
        self.assertEqual(len(records), 45)
        self.assertEqual(sum(r.feasible for r in records), 18)
        self.assertEqual((best.a_cm, best.b_cm), (12, 21))
        pair = [r for r in records if (r.a_cm, r.b_cm) == (15, 18)][0]
        self.assertTrue(pair.feasible)
        self.assertAlmostEqual(best.moment_Nm, pair.moment_Nm, delta=1e-11)
        self.assertGreater(best.margin_Hz, pair.margin_Hz)

    def test_30cm_325_candidates(self):
        model = CantileverFEM(BeamParameters(0.30, 0.10248, 0.099, 1.52448, 40))
        bands = AvoidanceBands((11.5, 14), (77, 87))
        records = evaluate_positions(model, bands, grid_positions(3, 27, 1))
        self.assertEqual(len(records), 325)
        best = choose_optimum(records)
        self.assertEqual((best.a_cm, best.b_cm), (16, 27))
        self.assertAlmostEqual(best.moment_Nm, 0.1651, delta=0.0001)


if __name__ == "__main__":
    unittest.main()
