"""Recompute the five A–E predictions and classification agreement of Table 5-5.

Measurements come from the uploaded research report and were not collected by this script.
"""
import csv
from pathlib import Path

from beam_optimizer import BeamParameters, AvoidanceBands, CantileverFEM, outside_band


ROOT = Path(__file__).resolve().parent


def main() -> None:
    model = CantileverFEM(BeamParameters(
        length_m=0.15, beam_mass_kg=0.05124, point_mass_kg=0.050,
        bending_rigidity_Nm2=1.52448, elements=40))
    ranges = AvoidanceBands((44, 60), (216, 330))
    with (ROOT / "data" / "validation_15cm_50g.csv").open(encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))

    mape1 = 0.0
    mape2 = 0.0
    matches = 0
    print("Case   Pred f1     Meas f1    Pred f2     Meas f2    MAPE1   MAPE2   Avoidance")
    for row in rows:
        a, b = float(row["a_cm"]), float(row["b_cm"])
        measured1, measured2 = float(row["f1_measured_Hz"]), float(row["f2_measured_Hz"])
        f1, f2 = model.frequencies(a, b)
        err1 = 100*abs(f1 - measured1)/measured1
        err2 = 100*abs(f2 - measured2)/measured2
        mape1 += err1
        mape2 += err2
        predicted_pass = outside_band(f1, ranges.first_Hz) and outside_band(f2, ranges.second_Hz)
        measured_pass = outside_band(measured1, ranges.first_Hz) and outside_band(measured2, ranges.second_Hz)
        matches += predicted_pass == measured_pass
        print(f"{row['label']:^4}  {f1:9.3f}  {measured1:9.3f}  {f2:9.3f}  {measured2:9.3f}  "
              f"{err1:5.2f}%  {err2:5.2f}%  "
              f"{'PASS' if predicted_pass else 'FAIL'} / {'PASS' if measured_pass else 'FAIL'}")
    print(f"Mean absolute percentage error: f1={mape1/len(rows):.2f}%, f2={mape2/len(rows):.2f}%")
    print(f"Avoidance classification matches: {matches}/{len(rows)}")


if __name__ == "__main__":
    main()
